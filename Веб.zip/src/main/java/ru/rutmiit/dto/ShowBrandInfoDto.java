package ru.rutmiit.dto;

public class ShowBrandInfoDto {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
